package es.pssstests.ejemplo.componentes;

public enum PersonaFisicaOJuridica {
	F,J
}
